import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

def main():
    df = pd.read_csv('dati_topo.csv') # Carica il dataset
    X = df[['mouse_x', 'cheese_x', 'cheese_y']] # attributi (da modificare se si vuole usare dati_topo_doppio.csv)
    y = df['azione']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = DecisionTreeClassifier(max_depth=5, random_state=42)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)

    print(f'Accuracy: {accuracy * 100:.2f}%')
    tree_rules = export_text(clf, feature_names=list(X.columns))
    print("Decision Tree Rules:")
    print(tree_rules)

if __name__ == "__main__":
    main()